# Code Citations

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ;
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2)
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) =
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ -
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac{
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac{(
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac{(x
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac{(x -
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac{(x - \\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac{(x - \\mu
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac{(x - \\mu)^
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac{(x - \\mu)^2
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac{(x - \\mu)^2}{
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac{(x - \\mu)^2}{2
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac{(x - \\mu)^2}{2 \\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac{(x - \\mu)^2}{2 \\sigma
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac{(x - \\mu)^2}{2 \\sigma ^
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac{(x - \\mu)^2}{2 \\sigma ^2
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
x ; \\mu,\\sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac{(x - \\mu)^2}{2 \\sigma ^2}
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/tree/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
sigma ^2) = \\frac{1}{\\sqrt{2 \\pi \\sigma ^2}}\\exp^{ - \\frac{(x - \\mu)^2}{2 \\sigma ^2}
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)},
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ld
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots,
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{
```

## License: unknown

https://github.com/ayushs0911/Machine-Learning-Specialization/tree/ae0324197df5c8b160f24e2b9cfdf5ff301e5c47/Unsupervised%20Learning%20/C3_W1_Anomaly_Detection.ipynb

```
\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y_{\\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})},
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y_{
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y_{\\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y_{\\rm
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y_{\\rm cv
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y_{\\rm cv}^{
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y_{\\rm cv}^{(
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y_{\\rm cv}^{(m
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y_{\\rm cv}^{(m_{
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y_{\\rm cv}^{(m_{\\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y_{\\rm cv}^{(m_{\\rm
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y_{\\rm cv}^{(m_{\\rm cv
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y_{\\rm cv}^{(m_{\\rm cv})
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y_{\\rm cv}^{(m_{\\rm cv})})
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y_{\\rm cv}^{(m_{\\rm cv})})\\
```

## License: unknown

https://github.com/usunyu/my-awesome-courses/blob/2b6eea1e60b561422975e94f82ed3c00e38e0c45/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Week%201/Practice%20Lab%202/C3_W1_Anomaly_Detection.ipynb

```
\\{(x_{\\rm cv}^{(1)}, y_{\\rm cv}^{(1)}),\\ldots, (x_{\\rm cv}^{(m_{\\rm cv})}, y_{\\rm cv}^{(m_{\\rm cv})})\\}$
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabil
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}),
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ld
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots,
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm cv
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm cv})
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm cv})})
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm cv})})$
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm cv})})$ se
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm cv})})$ se pasa
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm cv})})$ se pasa a
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm cv})})$ se pasa a `
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm cv})})$ se pasa a `select
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm cv})})$ se pasa a `select_threshold
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm cv})})$ se pasa a `select_threshold`
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm cv})})$ se pasa a `select_threshold` en
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm cv})})$ se pasa a `select_threshold` en el
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm cv})})$ se pasa a `select_threshold` en el vector
```

## License: unknown

https://github.com/emipaz/ml/tree/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm cv})})$ se pasa a `select_threshold`
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
de todas estas probabilidades $p(x_{\\rm cv}^{(1)}), \\ldots, p(x_{\\rm cv}^{(m_{\\rm cv})})$ se pasa a `select_threshold` en el vector `
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
*
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)},
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ld
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots,
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm cv
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm cv})
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm cv})}$
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm cv})}$ se
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm cv})}$ se pasan
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm cv})}$ se pasan a
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm cv})}$ se pasan a la
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm cv})}$ se pasan a la misma
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm cv})}$ se pasan a la misma función
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm cv})}$ se pasan a la misma función en
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm cv})}$ se pasan a la misma función en el
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm cv})}$ se pasan a la misma función en el vector
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm cv})}$ se pasan a la misma función en el vector `
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm cv})}$ se pasan a la misma función en el vector `y
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm cv})}$ se pasan a la misma función en el vector `y_val
```

## License: unknown

https://github.com/emipaz/ml/blob/a0fa3ca19656a3f61daea38af6f91e5ca2a15fc5/Unsupervised%20Learning%2C%20Recommenders%2C%20Reinforcement%20Learning/Semana_1/C3W1_A_2/C3_W1_Anomaly_Detection.ipynb

```
* Las etiquetas correspondientes $y_{\\rm cv}^{(1)}, \\ldots, y_{\\rm cv}^{(m_{\\rm cv})}$ se pasan a la misma función en el vector `y_val`
```
